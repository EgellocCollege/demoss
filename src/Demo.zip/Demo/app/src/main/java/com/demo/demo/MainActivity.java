package com.demo.demo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.LinearLayout;

import com.google.android.material.bottomsheet.BottomSheetBehavior;

public class MainActivity extends AppCompatActivity {
    LinearLayout linearLayout;
    WebView mWebview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        linearLayout = findViewById(R.id.bottom_sheet);

        final BottomSheetBehavior bottomSheetBehavior = BottomSheetBehavior.from(linearLayout);

        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);


        mWebview = findViewById(R.id.webview);
        mWebview.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View view, MotionEvent motionEvent) {
                mWebview.requestDisallowInterceptTouchEvent(mWebview.canScrollVertically(-1));
                return false;
            }
        });
        mWebview.loadUrl("https://www.douyin.com/");
        mWebview.getSettings().setUseWideViewPort(true);
    }
}
